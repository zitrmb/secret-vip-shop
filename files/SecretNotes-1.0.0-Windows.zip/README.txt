SECRET VIP PLUGINS - QUICK START

INSTALL
  Mac:      open the .pkg and follow the steps. It installs VST3, AU and CLAP.
  Windows:  copy the folder VST3\<Plugin>.vst3 to  C:\Program Files\Common Files\VST3
            copy the file   CLAP\<Plugin>.clap to  C:\Program Files\Common Files\CLAP
  Then restart your DAW (or rescan plugins).

ACTIVATE
  Open the plugin. Choose "Start 7-day trial" or paste your license key and press Activate.
  One key works on 2 computers. Moving to a new computer: gear icon -> License -> Deactivate.
  Lost your key? https://plugins.secret.vip/key

FIRST STEPS
  The welcome tour shows up on first launch (again any time: gear icon -> Welcome tour).
  All tricks: gear icon -> Help & Guide. Rest the mouse on anything to see what it does.

HELP
  support@secret.vip - we read every message.
  License terms: EULA.txt (in this folder) or https://plugins.secret.vip/eula

WINDOWS NOTE
  Not yet code-signed for Windows (works normally in your DAW).
  The interface needs Microsoft Edge WebView2 (built into Windows 11).
